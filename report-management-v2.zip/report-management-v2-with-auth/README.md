# Report Management Module (v2)

Report Management module for an Advertising Firm SE project. Built with **Java 17, Spring Boot 3, Spring Security, Spring Data JPA, Thymeleaf, and MySQL**.

## Features
- Login-protected: reports are scoped to the logged-in user automatically
- Create, edit, delete, and view reports
- Attach and download files
- Categorize reports (Campaign, Budget, Performance, Client, Other)
- Report status workflow: PENDING → APPROVED / REJECTED
- Filter reports by category and/or status
- Pagination (5 reports per page)
- Admin dashboard (ROLE_ADMIN only) to review, filter, paginate, and update the status of all reports

## Demo Login Accounts
| Username | Password | Role  | Access |
|----------|----------|-------|--------|
| user     | user123  | USER  | /reports (own reports only) |
| admin    | admin123 | ADMIN | /reports and /reports/admin (all reports) |

> These are hardcoded in `SecurityConfig.java` as placeholders. Swap the `InMemoryUserDetailsManager` bean for a real `UserDetailsService` once your team's user/auth module and users table are ready.

## Setup (IntelliJ IDEA)

1. **Open the project**: `File > Open` and select this folder. IntelliJ will detect it as a Maven project and download dependencies automatically.
2. **Create the database**: Make sure MySQL is running locally. The app will auto-create the `reportdb` database on first run (`createDatabaseIfNotExist=true`), but MySQL itself must be running.
3. **Set your credentials**: open `src/main/resources/application.properties` and update:
   ```
   spring.datasource.username=root
   spring.datasource.password=yourpassword
   ```
4. **Run**: open `ReportManagementApplication.java` and run the `main` method (or `mvn spring-boot:run`).
5. **Visit** `http://localhost:8080/reports` — you'll be redirected to `/login`. Log in with one of the demo accounts above.
   - `/reports` — logged-in user's own reports (filter + paginate)
   - `/reports/new` — create a report
   - `/reports/admin` — admin dashboard (only reachable by the `admin` account)

## Notes
- Reports are now tied to `Authentication.getName()` — whoever is logged in — instead of a `demoUser` placeholder.
- Uploaded files are stored in `uploads/reports/` at the project root (ignored by git — see `.gitignore`).
- Table `reports` is auto-created/updated by Hibernate (`spring.jpa.hibernate.ddl-auto=update`).
- Page size is 5 reports/page — change `PAGE_SIZE` in `ReportController.java` if you want a different value.

## Project Structure
```
src/main/java/com/advfirm/reportmanagement/
 ├── ReportManagementApplication.java
 ├── config/SecurityConfig.java
 ├── model/Report.java
 ├── repository/ReportRepository.java
 ├── service/ReportService.java
 └── controller/
      ├── ReportController.java
      └── LoginController.java

src/main/resources/
 ├── application.properties
 ├── templates/login.html
 ├── templates/reports/ (list, form, view, admin .html)
 └── static/css/style.css
```
