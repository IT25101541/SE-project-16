package com.advfirm.reportmanagement.repository;

import com.advfirm.reportmanagement.model.Report;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ReportRepository extends JpaRepository<Report, Long> {

    List<Report> findByCreatedBy(String createdBy);
    List<Report> findByStatus(String status);
    List<Report> findByCategory(String category);

    // Paginated + optionally filtered by category/status, scoped to one user
    @Query("SELECT r FROM Report r WHERE r.createdBy = :username " +
           "AND (:category IS NULL OR r.category = :category) " +
           "AND (:status IS NULL OR r.status = :status) " +
           "ORDER BY r.createdAt DESC")
    Page<Report> searchUserReports(@Param("username") String username,
                                    @Param("category") String category,
                                    @Param("status") String status,
                                    Pageable pageable);

    // Paginated + optionally filtered by category/status, across all users (admin)
    @Query("SELECT r FROM Report r WHERE " +
           "(:category IS NULL OR r.category = :category) " +
           "AND (:status IS NULL OR r.status = :status) " +
           "ORDER BY r.createdAt DESC")
    Page<Report> searchAllReports(@Param("category") String category,
                                   @Param("status") String status,
                                   Pageable pageable);
}
