package com.advfirm.reportmanagement.controller;

import com.advfirm.reportmanagement.model.Report;
import com.advfirm.reportmanagement.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    private static final int PAGE_SIZE = 5;

    // Paginated + filterable list of the logged-in user's own reports
    @GetMapping
    public String listReports(Model model,
                               Authentication authentication,
                               @RequestParam(required = false) String category,
                               @RequestParam(required = false) String status,
                               @RequestParam(defaultValue = "0") int page) {

        String username = authentication.getName();
        Pageable pageable = PageRequest.of(page, PAGE_SIZE);
        Page<Report> reportPage = reportService.searchUserReports(username, category, status, pageable);

        model.addAttribute("reportPage", reportPage);
        model.addAttribute("reports", reportPage.getContent());
        model.addAttribute("selectedCategory", category);
        model.addAttribute("selectedStatus", status);
        return "reports/list";
    }

    // Show create form
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("report", new Report());
        return "reports/form";
    }

    // Handle create
    @PostMapping("/save")
    public String createReport(@ModelAttribute Report report,
                                @RequestParam("file") MultipartFile file,
                                Authentication authentication) throws IOException {
        reportService.createReport(report, file, authentication.getName());
        return "redirect:/reports";
    }

    // Show edit form
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        model.addAttribute("report", reportService.getReportById(id));
        return "reports/form";
    }

    // Handle update
    @PostMapping("/update/{id}")
    public String updateReport(@PathVariable Long id,
                                @ModelAttribute Report report,
                                @RequestParam(value = "file", required = false) MultipartFile file) throws IOException {
        reportService.updateReport(id, report, file);
        return "redirect:/reports";
    }

    // Delete
    @GetMapping("/delete/{id}")
    public String deleteReport(@PathVariable Long id) {
        reportService.deleteReport(id);
        return "redirect:/reports";
    }

    // View single report
    @GetMapping("/view/{id}")
    public String viewReport(@PathVariable Long id, Model model) {
        model.addAttribute("report", reportService.getReportById(id));
        return "reports/view";
    }

    // Download attachment
    @GetMapping("/download/{id}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long id) throws MalformedURLException {
        Report report = reportService.getReportById(id);
        Path path = Paths.get(report.getFilePath());
        Resource resource = new UrlResource(path.toUri());

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + report.getFileName() + "\"")
                .body(resource);
    }

    // ---- ADMIN ENDPOINTS (protected by SecurityConfig: ROLE_ADMIN only) ----

    @GetMapping("/admin")
    public String adminDashboard(Model model,
                                  @RequestParam(required = false) String category,
                                  @RequestParam(required = false) String status,
                                  @RequestParam(defaultValue = "0") int page) {

        Pageable pageable = PageRequest.of(page, PAGE_SIZE);
        Page<Report> reportPage = reportService.searchAllReports(category, status, pageable);

        model.addAttribute("reportPage", reportPage);
        model.addAttribute("reports", reportPage.getContent());
        model.addAttribute("selectedCategory", category);
        model.addAttribute("selectedStatus", status);
        return "reports/admin";
    }

    @PostMapping("/admin/status/{id}")
    public String changeStatus(@PathVariable Long id, @RequestParam String status) {
        reportService.updateStatus(id, status);
        return "redirect:/reports/admin";
    }
}
